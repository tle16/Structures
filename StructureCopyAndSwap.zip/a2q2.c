#include "random.h"

struct Double_Array *shallow_copy(struct Double_Array *rui) {
    struct Double_Array *a_shallow;

    a_shallow = malloc(sizeof(struct Double_Array));
    *a_shallow  = *rui; /*a_shallow points towards the pointer which is pointed to the struct*/

    return a_shallow;
}

struct Double_Array *deep_copy(struct Double_Array *rui) {
    struct Double_Array *a_deep;
    int i, j;

    a_deep = malloc(sizeof(struct Double_Array));

    a_deep -> rowsize = rui -> rowsize;
    a_deep -> colsize = rui -> colsize;

    a_deep -> array = malloc(sizeof(double *) * a_deep -> rowsize);
    for(i = 0; i < a_deep -> rowsize; i++) {
        a_deep -> array[i] = malloc(sizeof(double) * a_deep -> colsize);
        for(j = 0; j < a_deep -> colsize; j++) {
            a_deep -> array[i][j] = rui -> array[i][j]; /*manually assigns values to the struct for deep copy*/
        }
    }

    return a_deep;
}

void print_struct(struct Double_Array *rui, char *header){

    printf("%s", header);
    printf("struct address = %p\n", &rui);
    printf("row_size = %d, col_size = %d\n", (int)rui -> rowsize, (int)rui -> colsize);
    printf("array address = %p, contents:\n\n", rui -> array);
    print_array(rui);
    printf("\n\n");
}