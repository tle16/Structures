#include "random.h"

int main() {
    struct Double_Array *Syad;

    printf("-------------------------------------\n\tQuestion 1\n-------------------------------------\n");
    Syad = double_array(COLUMNS, ROWS);
    randomize_array(Syad, 0, 999);
    print_array(Syad);
    swap_rows(Syad, rand() % (int)(Syad -> colsize + 1), rand() % (int)(Syad -> colsize + 1));
    swap_columns(Syad, rand() % (int)(Syad -> rowsize + 1), rand() % (int)(Syad -> rowsize + 1));
    free_array(Syad);

    return 0;
}