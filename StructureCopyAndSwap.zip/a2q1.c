#include "random.h"

struct Double_Array *double_array(int row, int col) {
    struct Double_Array *rui;
    int i;

    rui = malloc(sizeof(struct Double_Array));
    rui -> array = malloc(sizeof(double *) * row);
    for(i = 0; i < row; i++) {
        rui -> array[i] = malloc(sizeof(double) * col);
    }

    rui -> rowsize = row;
    rui -> colsize = col;

    return rui;
}

struct Double_Array *randomize_array(struct Double_Array *rui, double a, double b) {
    int i, j;

    for(i = 0; i < rui -> rowsize; i++) {
        for(j = 0; j < rui -> colsize; j++) {
            rui -> array[i][j] = rand_double(a, b); /*populates array with random numbers*/
        }
    }
    return rui;
}

void print_array(struct Double_Array *rui) {
    int i,j;

    for(i = 0; i < rui -> colsize; i++) {
        for(j = 0; j < rui -> rowsize; j++) {
            printf("%0.1f\t", rui -> array[j][i]);
        }
        printf("\n");
    }
}
double rand_double(double a, double b) {
    double holder = 0;
    double random_num;

    if (b < a) {
        holder = b;
        b = a;
        a = holder;

        random_num = ((double) rand() / (double) RAND_MAX)* (b - a)+ a;
    }
    else {
        random_num = ((double) rand() / (double) RAND_MAX)* (b - a) + a;
    }
    return random_num;
}

void free_array(struct Double_Array *rui) {
    int i;

    for(i = 0; i < rui -> rowsize; i++) {
        free(rui -> array[i]);
    }
    free(rui -> array);
    free(rui);
}

int swap_columns(struct Double_Array *rui, int a, int b) { 
    double *holder;

    if(rui -> rowsize > a && rui -> rowsize > b) {
        printf("\nSwapping column position %d with %d\n\n", a, b);
        holder = rui -> array[a];
        rui -> array[a] = rui -> array[b];
        rui -> array[b] = holder;
        print_array(rui);
        printf("\n\n\n");
    }
    else {
        printf("\nCould not swap columns\n\n");
        return 0;
    }
    return 1;
}

int swap_rows(struct Double_Array *rui, int a, int b) {
    double holder;
    int i;

    if(rui -> colsize > a && rui -> colsize > b) {
        printf("\nSwapping row position %d with %d\n\n", a, b);
        for(i = 0; i < rui -> rowsize; i++) {
            holder = rui -> array[i][a];
            rui -> array[i][a] = rui -> array[i][b];
            rui -> array[i][b] = holder;
        }
        print_array(rui);
    }
    else {
        printf("\nCould not swap rows\n\n");
    return 0;
    }
    return 1;
}