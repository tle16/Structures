#include "random.h"

int main() {
    struct Double_Array *a1;
    struct Double_Array *a2;
    struct Double_Array *a_shallow;
    struct Double_Array *a_deep;
    struct Double_Array *b1;
    char *header;
    int i;

    header = malloc(sizeof(char) * HEADERSIZE);
    for(i = 0; i < 4; i++) {
        if(i == 0) {
            strcpy(header, "the structure pointed to by a1 is:\n");
            printf("-------------------------------------\n\tQuestion 2a\n-------------------------------------\n");
            a1 = double_array(COLUMNS, ROWS);
            randomize_array(a1, 0, 10);
            printf("the address of a1 is %p\n", a1);
            print_struct(a1, header);
        }
        if(i == 1) {
            strcpy(header, "the structure pointed to by a2 is:\n");
            a2 = a1;
            printf("the address of a2 is %p\n", a2);
            print_struct(a2, header);
        }
        if(i == 2) {
            strcpy(header, "the structure pointed to by a_shallow is:\n");
            a_shallow = shallow_copy(a1);
            printf("the address of a_shallow is %p\n", a_shallow);
            print_struct(a_shallow, header);
        }
        if(i == 3) {
            strcpy(header, "the structrue pointd to by a_deep is:\n");
            a_deep = deep_copy(a1);
            printf("the address of a_deep is %p\n", a_deep);
            print_struct(a_deep, header);
        }
    }

    printf("-------------------------------------\n\tQuestion 2b\n-------------------------------------\n");
    a1 -> array[0][1] = 100.0;
    a2 -> array[1][2] = 200.0;
    a_shallow -> array[2][3] = 300.0;
    a_deep -> array[3][4] = 400.0;

    printf("a1\n");
    print_array(a1);
    printf("\n\na2\n");
    print_array(a2);
    printf("\n\na_shallow\n");
    print_array(a_shallow);
    printf("\n\na_deep\n");
    print_array(a_deep);
    printf("\n\n\n");

    printf("-------------------------------------\n\tQuestion 2c\n-------------------------------------\n");

    b1 = double_array(COLUMNS, ROWS);
    randomize_array(b1, 10, 20);
    a2 -> array = b1 -> array;

    printf("a1\n");
    print_array(a1);
    printf("\n\na2\n");
    print_array(a2);
    printf("\n\na_shallow\n");
    print_array(a_shallow);
    printf("\n\na_deep\n");
    print_array(a_deep);
    printf("\n\nb1\n");
    print_array(b1);
    printf("\n\n\n");

    a1 -> array[0][1] = 5000.0;
    a2 -> array[1][2] = 6000.0;
    a_shallow -> array[2][3] = 700.0;
    a_deep -> array[3][4] = 8000.0;
    b1 -> array[4][5] = 9000.0;

    printf("a1\n");
    print_array(a1);
    printf("\n\na2\n");
    print_array(a2);
    printf("\n\na_shallow\n");
    print_array(a_shallow);
    printf("\n\na_deep\n");
    print_array(a_deep);
    printf("\n\nb1\n");
    print_array(b1);
    printf("\n\n\n");

    free_array(a_deep);
    free_array(a_shallow);
    free_array(b1);
    free(a1);
    free(header);

    return 0;
}