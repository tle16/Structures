#ifndef BRU_H
#define  BRU_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define COLUMNS 9
#define ROWS 6
#define HEADERSIZE 45

struct Double_Array *double_array(int row, int col);
struct Double_Array *randomize_array(struct Double_Array *rui, double a, double b);
struct Double_Array *shallow_copy(struct Double_Array *rui);
struct Double_Array *deep_copy(struct Double_Array *rui);
int swap_rows(struct Double_Array * rui, int a, int b);
int swap_columns(struct Double_Array * rui, int a, int b);
double rand_double(double a, double b);
void print_array(struct Double_Array *rui);
void free_array(struct Double_Array *rui);
void print_struct(struct Double_Array *rui, char *header);

struct Double_Array {
    double **array;
    double rowsize;
    double colsize;
};

#endif